import argparse
import scrape23

parser = argparse.ArgumentParser(
    prog="Scrape23",
    description="Generates podcast Atom feeds from Youtube")

